import Foundation

//MARK: - Reduce

struct Calculator {
    
    // reduce method
    
    func reduce(_ nums: [Int], using nextPartialResult: (Int, Int) -> Int, startingAt initialResult: Int) -> Int {
        var total = initialResult
        for num in nums {
            total = nextPartialResult(total, num)
        }
        return total
    }
    
    // filter method
    
    func filter(_ nums: [Int], using isIncluded: (Int) -> Bool) -> [Int] {
        var filteredNums = [Int]()
        
        for num in nums {
            if isIncluded(num) {
                filteredNums.append(num)
            }
        }
        return filteredNums
    }
    
    // map method
    
    func map (_ nums: [Int], using transform:  (Int) -> Int) -> [Int] {
        var mappedNums = [Int]()
        
        for num in nums {
            mappedNums.append(transform(num))
        }
        
        return mappedNums
    }
    
    // sorted Method
    
    func sort (_ nums: [Int], by areInIncreasingOrder: (Int, Int) -> Bool) -> [Int] {
        var nums = nums
        
        for indexOne in 1..<nums.count {
            var indexTwo = indexOne
            while indexTwo > 0 && areInIncreasingOrder(nums[indexTwo], nums[indexTwo - 1]) {
                nums.swapAt(indexTwo - 1, indexTwo)
                indexTwo -= 1
            }
        }
        return nums
    }
    
}


//MARK: - Testing reduce method

let cal = Calculator()

let numbers1 = [1,2,3,4,5]
var addition = { (a: Int ,b: Int) -> Int in a + b }
let sum = cal.reduce(numbers1, using: addition, startingAt: 0)
print(sum)


//MARK: - Testing filter method

let numbers2 = [0,1,10,33,0,33,44,23,45,35,455, 34,33,35,99,0, 1000]
let filteredArray = cal.filter(numbers2) { value in value != 0 }
print(filteredArray)


//MARK: - Testing map method

let numbers3 = [2, 3, 4, 5, 5, 6, 7, 88]
let mapArray = cal.map(numbers3) { $0 + 10 }
print(mapArray)


//MARK: - Testing sort method

let numbers4 = [100, 50, 90, 40, 80, 30, 70, 20, 60, 10]
let sortArray = cal.sort(numbers4, by: > )
print(sortArray)
